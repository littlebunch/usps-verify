import ratpack.groovy.template.MarkupTemplateModule

import static ratpack.groovy.Groovy.groovyMarkupTemplate
import static ratpack.groovy.Groovy.ratpack
import static groovy.json.JsonOutput.toJson
import ratpack.hikari.HikariModule
import gov.usda.nal.ndb.User
import gov.usda.nal.ndb.UserService
import gov.usda.nal.ndb.DefaultUserService
import groovy.json.JsonSlurper
import app.ApplicationConfig

ratpack {
  serverConfig {
    json "dbconfig.json"
    yaml "dbconfig.yml"
    env()
    sysProps()
    require("",ApplicationConfig)
  }
  bindings {
    // load our application config from the serverConfig for use in bindings
    ApplicationConfig appConfig
    serverConfig.requiredConfig.each {
      if ( it.object instanceof ApplicationConfig) {
        appConfig=it.object
        return
      }
    }
    module MarkupTemplateModule
    bindInstance UserService, new DefaultUserService()
    module GormModule
    bindInstance new Service() {
      void onStart(StartEvent e) throws Exception {
          e.getRegistry().get(HibernateDatastoreSpringInitializer)
          Blocking.exec {
            User.withNewSession {
                new User(name:"Gary Moore",email:"gary@littlebunch.com").save()
                new User(name:"Jen Moore",email:"jenamoore@gmail.com").save()
            }
          }
        }
      }
    }
    bindInstance JsonSlurper, new JsonSlurper()
    module(HikariModule) { c ->
      //c.driverClassName=appConfig.database.driver
      c.dataSourceClassName=appConfig.database.dataSourceClass
      c.jdbcUrl=appConfig.database.url
      c.username=appConfig.database.user
      c.password=appConfig.database.password
    }
  }

  handlers {
    path('api') {JsonSlurper jsonSlurper, UserService userService ->
      byMethod {
        post {
          request.body.map {body ->
            jsonSlurper.parseText(body.text) as Map
        }.map { data->
          new User(data)
        }.flatMap { user ->
          userService.save(user)
        }.then {
          response.send()
        }
      }

        get {
          userService.getUsers().then { users->
            response.send(toJson(users))
          }
        }
      }
    }
    get("config")
    {
      ApplicationConfig config ->
        render toJson(config)
    }
    get {
      render groovyMarkupTemplate("index.gtpl", title: "My Ratpack App")
    }

    files { dir "public" }
  }
}
